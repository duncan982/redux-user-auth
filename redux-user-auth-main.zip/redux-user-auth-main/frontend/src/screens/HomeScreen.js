const HomeScreen = () => {
  return <h1>User Authentication with Redux Toolkit & JWTs</h1>
}

export default HomeScreen
